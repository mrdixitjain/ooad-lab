import java.util.Scanner;


class Student extends Person
{
     String Hobby = "Facebook" ;
    

    public Student(String name)
    {
        super(name);
    }

    public String getHobby() {
        return Hobby;
    }

    public void setHobby(String hobby) {
        Hobby = hobby;
    }
    
}



class CBSEStudent extends Student
{
    private String Hobby = "Hacking" ;
    
    public CBSEStudent(String name)
    {
        super(name);
    }

    public String getHobby() {
        return Hobby;
    }

    public void setHobby(String hobby) {
        Hobby = hobby;
    }
    
}


 class Person 
{
    private String Hobby = "Reading" ;
    private String name;

    public Person( String name )
    {
        this.name = name;
    }

    public String getName()
    {
        return this.name;
    }

    public void introduce ()
    {
        System.out.println(" Hello , my name is " + this.getName() + " and my hobby is " + this.getHobby());
    }
    public String getHobby()
    {
        return this.Hobby;
    }

}

public class Question2
{
    public static void main(String[] args)
    {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter name");
        String name = sc.nextLine();

        
        
        

        int i = 3 ;
        while( i > 0)
        {
            i--;

            System.out.println(" 1..... cbse student");
            System.out.println(" 2..... student");
            System.out.println(" 3..... person");
    
            System.out.println("Enter choice");
            int ch = sc.nextInt();
    
            switch(ch)
            {
                case 1 : Person person3 = new CBSEStudent(name);
                         person3.introduce();
                         break ;

                case 2 : Person person2 = new Student(name);
                         person2.introduce();
                        break;

                case 3 : Person person = new Person(name);
                          person.introduce();
                break;

                default : System.out.println("wrong choice ");
                          break;

            }

        }
        sc.close();
    }
}