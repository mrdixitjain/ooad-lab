package fact_final;

import java.util.Scanner;

import fact_recursion.Factorial;

public class Fact 
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the no to find factorial : ");
        int n = sc.nextInt();

        try 
        {
            Factorial factorial = new Factorial();

            System.out.println("factorial  = " + factorial.factorial(n));
            
        } catch (Exception e) {
            e.printStackTrace();
        }
           
            
        sc.close();
    
        
    }

}