class Main{
	public static void main(String[] args){
		Results s1 = new Results("2017ucp1401", "dixit jain", "CSE2K17 B");

		s1.setObtainedMarks(0, 50f);
		s1.setObtainedMarks(1, 40f);
		s1.setSports(true);

		System.out.println(s1.totalMarks());
		s1.setSports(false);
		System.out.println(s1.totalMarks());
	}
}