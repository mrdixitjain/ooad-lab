class Exam extends Student {
	
	final static int n=2;
	String[] subjectName = new String[] {"English, Maths"};
	int[] maxMarks = new int[] {100, 100};
	float[] marksObtained = new float[] {-1f, -1f};
	// for (int i=0; i<n; i++)
	// 	marksObtained[i]=-1f;
	

	public Exam(String id, String name, String batch){
		super(id, name, batch, false);
	}


	public void setObtainedMarks(int subjectNumber, float obtMarks){
		if(subjectNumber>=n || subjectNumber<0){
			System.out.println("Subject is not listed.");
			return;
		}
		else if(obtMarks>this.maxMarks[subjectNumber]){
			System.out.println("Obtained marks more than max marks are not allowed.");
			return;
		}

		this.marksObtained[subjectNumber]=obtMarks;

	}

	public float getObtainedMarks(int subjectNumber){
		if(subjectNumber>=n || subjectNumber<0){
			System.out.println("Subject is not listed.");
			return -1f;
		}

		else if(this.marksObtained[subjectNumber]==-1){
			System.out.println("obtained marks are not updated for this subject yet.");
			return -1f;
		}

		return this.marksObtained[subjectNumber];
	}

	public float getMaxMarks(int subjectNumber){
		if(subjectNumber>=n || subjectNumber<0){
			System.out.println("Subject is not listed.");
			return -1f;
		}

		else if(this.maxMarks[subjectNumber]==-1){
			System.out.println("max marks are not updated for this subject yet.");
			return -1f;
		}

		return this.maxMarks[subjectNumber];
	}

	public float getExamMarks(){
		float totalMarks=0;
		for(int i=0; i<n; i++){
			if(marksObtained[i]==-1){
				System.out.println("obtained marks are not updated for " + (subjectName[i])+" yet.");
				return -1f;
			}
			totalMarks+=marksObtained[i];
		}
		return totalMarks;
	}

	public boolean inSports(){
		return super.getSports();
	}

}