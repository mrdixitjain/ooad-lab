class Results extends Exam implements Sports {

	public Results(String id, String name, String batch){
		super(id, name, batch);

	}

	public int getSportsMarks(){
		return sportsMarks;
	}

	public float totalMarks(){
		float totalMarks=0;
		if(this.inSports())
			totalMarks+=this.getSportsMarks();
		totalMarks+=super.getExamMarks();
		return totalMarks;
	}
}