interface Sports
{
    int sportsMarks = 30;
    int getSportsMarks( );

}