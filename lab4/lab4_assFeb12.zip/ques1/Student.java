class Student{
	String id;
	String name;
	String batch;
	boolean inSports=false;

	public Student(String id, String name, String batch, boolean inSports){
		this.id=id;
		this.batch=batch;
		this.name=name;
		this.inSports=inSports;
	}

	public String getId(){
		return this.id;
	}

	// public void setId(String id){
	// 	this.id=id;
	// }

	public String getName(){
		return this.name;
	}

	// public void setName(String name){
	// 	this.name=name;
	// }

	public String getBatch(){
		return this.batch;
	}

	public void setSports(boolean in){
		this.inSports=in;
	}

	public boolean getSports(){
		return this.inSports;
	}



	// public void setBatch(String Batch){
	// 	this.batch=batch;
	// }
}