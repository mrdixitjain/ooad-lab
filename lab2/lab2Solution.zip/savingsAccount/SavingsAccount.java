public class SavingsAccount {
	static float annualInterestRate;
	private double savingsBalance;

	public SavingsAccount(){
		this(12f, 0);
		System.out.println("constructor with 0 arguments called");
	}

	public SavingsAccount(float annualInterestRate, double savingsBalance){
		this.savingsBalance=savingsBalance;
		this.annualInterestRate=annualInterestRate;
	}

	public double getBalance(){
		return this.savingsBalance;
	}

	public float getInterestRate(){
		return this.annualInterestRate;
	}

	public void depositMoney(double amount){
		this.savingsBalance+=amount;
		System.out.println(amount+" has been added.");
	}

	public void withdrawMoney(double amount){
		if(amount<this.savingsBalance){
			this.savingsBalance-=amount;
			System.out.println(amount+" has been withdrawl.");
			System.out.println("remaining balance: "+this.savingsBalance);
		}
		else{
			System.out.println("insufficient balance");
			System.out.println("current balance: "+this.savingsBalance);
		}
	}

	public double calculateMonthlyInterest(){
		double monthlyInterest = this.savingsBalance*this.annualInterestRate/1200;
		this.savingsBalance+=monthlyInterest;
		return monthlyInterest;
	}

	public void modifyInterestRate(float newRate){
		this.annualInterestRate=newRate;
		System.out.println("Interest rate updated to "+newRate);
	}
}