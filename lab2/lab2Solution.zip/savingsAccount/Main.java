public class Main {
	
	public static void main(String[] args){
		SavingsAccount saver1 = new SavingsAccount(4f, 2000);
		SavingsAccount saver2 = new SavingsAccount(4f, 3000);

		System.out.println(saver1.calculateMonthlyInterest());
		System.out.println(saver2.calculateMonthlyInterest());
		System.out.println(saver1.getBalance());
		System.out.println(saver2.getBalance());
		saver1.modifyInterestRate(5f);
		saver2.modifyInterestRate(5f);
		System.out.println(saver1.calculateMonthlyInterest());
		System.out.println(saver2.calculateMonthlyInterest());
		System.out.println(saver1.getBalance());
		System.out.println(saver2.getBalance());

	}
}