public class Main {
	public static void main(String[] args){
		Rectangle r=new Rectangle();
		System.out.println(r.getLength());
		System.out.println(r.getWidth());
		r.setWidth(21f);
		r.setWidth(15f);
		r.setLength(0f);
		r.setLength(12f);
		System.out.println(r.getArea());
		System.out.println(r.getPerimeter());
	}
}