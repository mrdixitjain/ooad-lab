class Rectangle {
	private float length=1;
	private	float width=1;

	public void setWidth(float width){
		if(width>0f && width<20f){
			this.width = width;
		}
		else{
			System.out.println("invalid width");
		}
	}
	public float getWidth(){
		return this.width;
	}

	public void setLength(float length){
		if(length>0f && length<20f){
			this.length = length;
		}
		else{
			System.out.println("invalid length");
		}
	}
	public float getLength(){
		return this.length;
	}

	public float getArea(){
		return this.length*this.width;
	}

	public float getPerimeter(){
		return 2*(this.length+this.width);
	}
}